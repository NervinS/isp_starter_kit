// app/api/usuarios/route.ts
import { NextRequest, NextResponse } from 'next/server';

const BASE =
  process.env.API_BASE_SSR && process.env.API_BASE_SSR.startsWith('http')
    ? process.env.API_BASE_SSR
    : 'http://127.0.0.1:3000/v1';

// Cache simple del JWT del técnico
let tecJwtCache: { token: string; expMs: number } | null = null;

function decodeJwtExpMs(token: string): number | null {
  try {
    const [, payload] = token.split('.');
    if (!payload) return null;
    // base64url -> base64
    const b64 = payload.replace(/-/g, '+').replace(/_/g, '/');
    const json = Buffer.from(b64, 'base64').toString('utf8');
    const obj = JSON.parse(json);
    return obj?.exp ? obj.exp * 1000 : null;
  } catch {
    return null;
  }
}

async function getTecJwt(): Promise<string> {
  const now = Date.now();
  if (tecJwtCache && tecJwtCache.expMs > now + 5000) {
    return tecJwtCache.token;
  }
  const username = process.env.TEC_USER || 'tec1';
  const password = process.env.TEC_PASS || 'Tec123!';

  const r = await fetch(`${BASE}/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  if (!r.ok) {
    throw new Error(`login tec fallo (${r.status})`);
  }
  const data = await r.json();
  const token: string = data?.access_token || '';
  if (!token) throw new Error('login tec sin token');

  const expMs = decodeJwtExpMs(token) ?? now + 10 * 60 * 1000;
  tecJwtCache = { token, expMs };
  return token;
}

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q') ?? '';
  const url = new URL(`${BASE}/usuarios`);
  if (q) url.searchParams.set('q', q);

  // 1) usa (o obtiene) un JWT de técnico
  let token = '';
  try {
    token = await getTecJwt();
  } catch {
    // plan B: variables antiguas si existen
    token =
      process.env.SERVER_TEC_JWT ||
      process.env.API_TECH_TOKEN ||
      '';
  }

  // 2) dispara contra el backend
  let res = await fetch(url.toString(), {
    cache: 'no-store',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });

  // 3) Si el backend responde 401, refresca el token y reintenta 1 vez
  if (res.status === 401) {
    tecJwtCache = null; // invalida cache
    const fresh = await getTecJwt();
    res = await fetch(url.toString(), {
      cache: 'no-store',
      headers: { Authorization: `Bearer ${fresh}` },
    });
  }

  const text = await res.text();
  return new NextResponse(text, {
    status: res.status,
    headers: {
      'content-type':
        res.headers.get('content-type') ?? 'application/json; charset=utf-8',
      'x-proxy-auth': 'tec',
    },
  });
}

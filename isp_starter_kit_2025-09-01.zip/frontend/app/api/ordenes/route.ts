import { NextRequest, NextResponse } from 'next/server';

// Base del backend
const API_BASE =
  process.env.API_BASE_SSR && process.env.API_BASE_SSR.startsWith('http')
    ? process.env.API_BASE_SSR
    : 'http://127.0.0.1:3000/v1';

// Cache volátil en memoria del proceso de Next
let TEC_JWT_CACHE: string | null = null;
let TEC_JWT_TS = 0;

// Login técnico (si no hay token en .env)
async function loginTecnico(): Promise<string> {
  const username = process.env.TEC_USER || 'tec1';
  const password = process.env.TEC_PASS || 'Tec123!';

  const r = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });

  if (!r.ok) {
    const msg = await r.text().catch(() => '');
    throw new Error(`login técnico falló (${r.status}) ${msg}`);
  }
  const data = await r.json();
  const token: string | undefined = data?.access_token;
  if (!token) throw new Error('login técnico no devolvió access_token');
  return token;
}

// Obtiene JWT válido: .env -> cache -> login
async function getTecJwt(): Promise<string> {
  const envToken = process.env.SERVER_TEC_JWT || process.env.API_TECH_TOKEN;
  if (envToken && envToken.trim()) return envToken.trim();

  // cache 10 min para evitar logins repetidos
  const now = Date.now();
  if (TEC_JWT_CACHE && now - TEC_JWT_TS < 10 * 60 * 1000) return TEC_JWT_CACHE;

  const jwt = await loginTecnico();
  TEC_JWT_CACHE = jwt;
  TEC_JWT_TS = now;
  return jwt;
}

// Hace la petición al backend con JWT y reintenta 1 vez si da 401
async function fetchWithTecAuth(input: string, init?: RequestInit) {
  let jwt = await getTecJwt();
  let res = await fetch(input, {
    ...init,
    headers: {
      ...(init?.headers || {}),
      Authorization: `Bearer ${jwt}`,
    },
  });

  if (res.status === 401) {
    // refresca token y reintenta una vez
    TEC_JWT_CACHE = null;
    jwt = await getTecJwt();
    res = await fetch(input, {
      ...init,
      headers: {
        ...(init?.headers || {}),
        Authorization: `Bearer ${jwt}`,
      },
    });
  }
  return res;
}

export async function GET(req: NextRequest) {
  try {
    const estado = req.nextUrl.searchParams.get('estado') ?? '';
    const url = new URL(`${API_BASE}/ordenes`);
    if (estado) url.searchParams.set('estado', estado);

    const be = await fetchWithTecAuth(url.toString(), { cache: 'no-store' });

    const text = await be.text();
    const type =
      be.headers.get('content-type') || 'application/json; charset=utf-8';
    return new NextResponse(text, {
      status: be.status,
      headers: { 'content-type': type, 'x-proxy-auth': 'tec' }, // pista útil
    });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, err: e?.message || 'fetch failed' },
      { status: 500 },
    );
  }
}


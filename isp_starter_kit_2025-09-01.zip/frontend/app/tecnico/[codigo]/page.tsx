'use client';

import { useState } from 'react';
import SignaturePad from '../../../components/SignaturePad';

type Props = { params: { codigo: string } };

const API_PROXY_BASE = '/api'; // usamos el proxy local de Next

/** Lee imagen del <input>, la comprime aprox a 1280px lado mayor y devuelve dataURL PNG/JPEG */
async function readAndCompress(file: File, maxSize = 1280): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('Archivo no es imagen');

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result as string);
    fr.onerror = reject;
    fr.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.onerror = reject;
    i.src = dataUrl;
  });

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;
  let { width, height } = img;
  const scale = Math.min(1, maxSize / Math.max(width, height));
  width = Math.round(width * scale);
  height = Math.round(height * scale);
  canvas.width = width;
  canvas.height = height;
  ctx.drawImage(img, 0, 0, width, height);

  const mime = file.type.includes('png') ? 'image/png' : 'image/jpeg';
  const out = canvas.toDataURL(mime, mime === 'image/jpeg' ? 0.85 : undefined);
  return out;
}

export default function CerrarOrdenPage({ params }: Props) {
  const { codigo } = params;

  // Campos del formulario (con valores por defecto)
  const [tecnico, setTecnico] = useState('TEC-001');
  const [lat, setLat] = useState<number | ''>(4.711);
  const [lng, setLng] = useState<number | ''>(-74.072);
  const [onu, setOnu] = useState('ZTEG12345678');
  const [vlan, setVlan] = useState('110');
  const [precinto, setPrecinto] = useState('P-0001');

  const [fotos, setFotos] = useState<string[]>([]); // dataURL
  const [firma, setFirma] = useState<string>('');   // dataURL (image/png)

  const [subiendo, setSubiendo] = useState(false);
  const [resultado, setResultado] = useState<string>('');

  async function handleGPS() {
    if (!navigator.geolocation) return alert('Geolocalización no disponible');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(Number(pos.coords.latitude.toFixed(6)));
        setLng(Number(pos.coords.longitude.toFixed(6)));
      },
      (err) => alert(`Error GPS: ${err.message}`),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  // Manejo de <input type="file" multiple>
  async function onFilesChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const toRead = Array.from(files).slice(0, 5); // máx 5
    const outs: string[] = [];
    for (const f of toRead) outs.push(await readAndCompress(f, 1280));
    setFotos(outs);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setResultado('');

    if (fotos.length === 0) {
      alert('Debes subir al menos 1 foto');
      return;
    }
    if (!firma) {
      alert('Debes capturar la firma');
      return;
    }

    // IMPORTANTE: el backend espera 'tecnico_codigo' y BODY JSON
    const payload = {
      tecnico_codigo: tecnico,
      lat: lat === '' ? null : Number(lat),
      lng: lng === '' ? null : Number(lng),
      onu_serial: onu || null,
      vlan: vlan || null,
      precinto: precinto || null,
      fotos,
      firma,
    };

    try {
      setSubiendo(true);
      const res = await fetch(`${API_PROXY_BASE}/ordenes/${codigo}/cerrar-completo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        cache: 'no-store',
      });

      const text = await res.text();
      if (!res.ok) setResultado(`HTTP ${res.status}: ${text.slice(0, 400)}`);
      else setResultado(text);
    } catch (err: any) {
      setResultado(`Error: ${err?.message || String(err)}`);
    } finally {
      setSubiendo(false);
    }
  }

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontSize: 36, fontWeight: 800 }}>Cerrar Orden {codigo}</h1>

      <form onSubmit={onSubmit} style={{ display: 'grid', gap: 10, maxWidth: 720 }}>
        <label>
          Técnico
          <input value={tecnico} onChange={(e) => setTecnico(e.target.value)} />
        </label>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 8 }}>
          <label>
            Lat
            <input
              value={lat}
              onChange={(e) => setLat(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="lat"
            />
          </label>
          <button type="button" onClick={handleGPS}>GPS</button>
          <label>
            Lng
            <input
              value={lng}
              onChange={(e) => setLng(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="lng"
            />
          </label>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          <label>
            ONU Serial
            <input value={onu} onChange={(e) => setOnu(e.target.value)} />
          </label>
          <label>
            VLAN
            <input value={vlan} onChange={(e) => setVlan(e.target.value)} />
          </label>
          <label>
            Precinto
            <input value={precinto} onChange={(e) => setPrecinto(e.target.value)} />
          </label>
        </div>

        <div>
          <div>Fotos (máx 5, se comprimen a ~1280px)</div>
          <input type="file" multiple accept="image/*" onChange={onFilesChange} />
          {fotos.length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 10 }}>
              {fotos.map((f, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={i} src={f} alt={`foto-${i}`} style={{ width: '100%', border: '1px solid #ccc' }} />
              ))}
            </div>
          )}
        </div>

        <div>
          <div>Firma del cliente</div>
          <SignaturePad onChange={(dataUrl) => setFirma(dataUrl)} height={180} />
          <div style={{ fontSize: 12, color: '#666' }}>Firme dentro del recuadro</div>
        </div>

        <button type="submit" disabled={subiendo} style={{ padding: '6px 10px' }}>
          {subiendo ? 'Enviando…' : 'Cerrar Orden'}
        </button>
      </form>

      {resultado && (
        <pre style={{ background: '#f5f5f5', padding: 12, marginTop: 16, whiteSpace: 'pre-wrap' }}>
          {resultado}
        </pre>
      )}

      <div style={{ marginTop: 12 }}>
        <a href="/tecnico">Volver al listado</a>
      </div>
    </div>
  );
}

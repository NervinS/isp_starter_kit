'use client';

import { useEffect, useMemo, useState } from 'react';

type OrdenRow = {
  codigo: string;
  estado: string;
  tipo: string;
  created_at: string;
  venta?: { codigo: string; total: string };
  usuario?: { codigo: string; nombre: string };
};

export default function TecnicoPage() {
  const API = (process.env.NEXT_PUBLIC_API_BASE || '/api').replace(/\/+$/, '');
  const [ordenes, setOrdenes] = useState<OrdenRow[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState('');

  async function cargar() {
    setLoading(true);
    setErr(null);
    try {
      const res = await fetch(`${API}/ordenes?estado=pendiente`, { cache: 'no-store' });
      const text = await res.text();
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${text}`);
      const data = JSON.parse(text) as OrdenRow[];
      setOrdenes(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setErr(e?.message || String(e));
      setOrdenes([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { cargar(); /* eslint-disable-next-line */ }, []);

  const filtradas = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return ordenes;
    return ordenes.filter(o =>
      o.codigo.toLowerCase().includes(term) ||
      (o.usuario?.nombre || '').toLowerCase().includes(term) ||
      (o.tipo || '').toLowerCase().includes(term)
    );
  }, [ordenes, q]);

  const fmtDate = (s?: string) => {
    if (!s) return '—';
    const d = new Date(s);
    if (isNaN(d.getTime())) return s;
    return d.toLocaleString('es-CO', { dateStyle: 'medium', timeStyle: 'short' });
  };

  const fmtMoney = (v?: string) => {
    const n = Number(v || 0);
    return n ? `$${n.toLocaleString('es-CO')}` : '—';
  };

  return (
    <div style={styles.page}>
      <div style={styles.shell}>
        <header style={styles.header}>
          <div>
            <h1 style={styles.title}>Órdenes pendientes</h1>
            <p style={styles.subtitle}>Tareas asignadas listas para atender.</p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={cargar} style={styles.btnPrimary} aria-label="Recargar lista">Recargar</button>
          </div>
        </header>

        {/* Filtro */}
        <div style={styles.toolbar}>
          <input
            style={styles.input}
            placeholder="Buscar por código, cliente o tipo…"
            value={q}
            onChange={e => setQ(e.target.value)}
          />
        </div>

        {/* Alertas */}
        {err && <div style={styles.alertError}>{err}</div>}

        {/* Lista / estados */}
        <div style={styles.card}>
          {loading ? (
            <div style={{ padding: 16 }}>
              <div style={styles.skeletonRow} />
              <div style={styles.skeletonRow} />
              <div style={styles.skeletonRow} />
            </div>
          ) : filtradas.length === 0 ? (
            <div style={styles.empty}>
              <div style={styles.emptyIcon}>🗒️</div>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Sin órdenes por ahora</div>
              <div style={{ color: '#64748b' }}>Cuando se creen nuevas órdenes aparecerán aquí.</div>
            </div>
          ) : (
            <ul style={styles.list}>
              {filtradas.map((o) => (
                <li key={o.codigo} style={styles.row}>
                  <div style={styles.rowMain}>
                    <a href={`/tecnico/${encodeURIComponent(o.codigo)}`} style={styles.codeLink}>
                      {o.codigo}
                    </a>
                    <span style={{ ...styles.badge, ...(o.estado === 'pendiente' ? styles.badgeWarn : styles.badgeOk) }}>
                      {o.estado.toUpperCase()}
                    </span>
                    <span style={styles.dot} />
                    <span style={styles.type}>{o.tipo || '—'}</span>
                  </div>

                  <div style={styles.rowMeta}>
                    <span title="Cliente" style={styles.metaItem}>
                      👤 {o.usuario?.nombre || '—'}
                    </span>
                    <span title="Venta" style={styles.metaItem}>
                      🧾 {o.venta?.codigo || '—'}
                    </span>
                    <span title="Valor" style={styles.metaItem}>
                      💵 {fmtMoney(o.venta?.total)}
                    </span>
                    <span title="Creada" style={styles.metaItem}>
                      🕒 {fmtDate(o.created_at)}
                    </span>
                  </div>

                  <div>
                    <a href={`/tecnico/${encodeURIComponent(o.codigo)}`} style={styles.btnGhost}>
                      Ver detalle
                    </a>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------- Estilos (UI SaaS/CRM, sin dependencias) ---------- */
const styles: Record<string, any> = {
  page: {
    background: '#f4f6f8',
    minHeight: '100vh',
    fontFamily: 'Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif',
    color: '#0f172a',
    padding: '32px 16px',
  },
  shell: { maxWidth: 1100, margin: '0 auto' },
  header: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  title: { margin: 0, fontSize: 28, fontWeight: 800, letterSpacing: .2 },
  subtitle: { margin: 0, color: '#64748b' },

  toolbar: { margin: '12px 0 16px', display: 'flex', gap: 10 },
  input: {
    flex: 1, padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 12,
    outline: 'none', background: '#fff', boxShadow: 'inset 0 1px 0 rgba(0,0,0,.02)'
  },

  card: {
    background: '#fff', borderRadius: 16, boxShadow: '0 10px 30px rgba(2,12,27,.08)', overflow: 'hidden'
  },

  list: { listStyle: 'none', margin: 0, padding: 0 },
  row: {
    display: 'grid',
    gridTemplateColumns: '1.2fr 1fr auto',
    gap: 12, alignItems: 'center',
    padding: '14px 16px',
    borderBottom: '1px solid #eef2f7',
  },
  rowMain: { display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 },
  rowMeta: { display: 'flex', flexWrap: 'wrap', gap: 12, color: '#475569', fontSize: 14 },

  codeLink: {
    color: '#1d4ed8', textDecoration: 'none', fontWeight: 800, background: '#eef2ff',
    padding: '6px 10px', borderRadius: 10
  },
  type: { color: '#0f172a', fontWeight: 600 },
  dot: { width: 6, height: 6, borderRadius: 999, background: '#cbd5e1', display: 'inline-block' },

  badge: {
    fontSize: 12, fontWeight: 800, padding: '4px 8px', borderRadius: 999,
    border: '1px solid transparent'
  },
  badgeWarn: { background: '#fff7ed', color: '#9a3412', borderColor: '#fed7aa' },
  badgeOk: { background: '#ecfdf5', color: '#065f46', borderColor: '#a7f3d0' },

  btnPrimary: {
    background: '#2563eb', color: '#fff', border: 'none',
    padding: '10px 14px', borderRadius: 12, cursor: 'pointer',
    boxShadow: '0 6px 14px rgba(37,99,235,.18)', fontWeight: 700
  },
  btnGhost: {
    background: '#eef2ff', color: '#1e3a8a', border: '1px solid #c7d2fe',
    padding: '8px 12px', borderRadius: 12, textDecoration: 'none', fontWeight: 700
  },

  alertError: {
    background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b',
    padding: '10px 12px', borderRadius: 12, marginBottom: 12
  },

  empty: { padding: 36, textAlign: 'center' },
  emptyIcon: { fontSize: 28, marginBottom: 8 },

  skeletonRow: {
    height: 54, borderRadius: 12, background: 'linear-gradient(90deg,#f3f4f6 25%,#e5e7eb 37%,#f3f4f6 63%)',
    backgroundSize: '400% 100%', animation: 'sweep 1.4s ease infinite', marginBottom: 10
  }
};

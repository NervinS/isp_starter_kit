// app/ordenes/page.tsx
// Server Component – siempre SSR y sin usar rutas relativas /api/*
export const dynamic = 'force-dynamic';

type OrdenLite = {
  codigo: string;
  estado: string;
  tipo: string;
  created_at?: string;
  venta?: { codigo: string; total: string };
  usuario?: { codigo: string; nombre: string };
};

const API =
  process.env.API_BASE_SSR ||
  process.env.NEXT_PUBLIC_API_BASE ||
  'http://127.0.0.1:3000/v1';

const TEC_JWT = process.env.API_TECH_TOKEN || '';

async function getPendientes(): Promise<{ items: OrdenLite[]; error?: string }> {
  try {
    const r = await fetch(`${API}/ordenes?estado=pendiente`, {
      cache: 'no-store',
      headers: TEC_JWT ? { Authorization: `Bearer ${TEC_JWT}` } : {},
    });

    const text = await r.text();
    if (!r.ok) return { items: [], error: `HTTP ${r.status}: ${text.slice(0, 200)}` };

    try {
      const data = JSON.parse(text);
      return { items: Array.isArray(data) ? data : [] };
    } catch {
      return { items: [], error: `Respuesta no JSON: ${text.slice(0, 200)}` };
    }
  } catch (e: any) {
    return { items: [], error: e?.message || 'Fetch error' };
  }
}

export default async function OrdenesPendientesPage() {
  const { items, error } = await getPendientes();

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontSize: 28, fontWeight: 800 }}>Órdenes pendientes</h1>

      {error && <div style={{ color: 'crimson', marginTop: 8 }}>{error}</div>}

      {items.length === 0 ? (
        <p>• No hay órdenes pendientes.</p>
      ) : (
        <ul style={{ marginTop: 12 }}>
          {items.map((o) => (
            <li key={o.codigo} style={{ marginBottom: 8 }}>
              <strong>{o.codigo}</strong> — {o.usuario?.nombre || o.usuario?.codigo || '—'} —{' '}
              {o.tipo} — {new Date(o.created_at || '').toLocaleString()}
            </li>
          ))}
        </ul>
      )}

      <div style={{ marginTop: 12 }}>
        <a href="/ordenes" style={{ padding: '6px 10px', border: '1px solid #000', borderRadius: 6 }}>
          Recargar
        </a>
        <a
          href="/tecnico"
          style={{ marginLeft: 10, padding: '6px 10px', border: '1px solid #000', borderRadius: 6 }}
        >
          Ir a /tecnico
        </a>
      </div>
    </div>
  );
}

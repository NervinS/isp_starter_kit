/** @type {import('next').NextConfig} */
const nextConfig = {
  // sin experimental.allowedDevOrigins (tu patch de Next no lo soporta)
};

module.exports = nextConfig;

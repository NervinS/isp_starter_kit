'use client';
import React, { useRef, useEffect, useState } from 'react';

type Props = { width?: number; height?: number; onChange?: (dataUrl: string)=>void };

export default function SignaturePad({ width=360, height=180, onChange }: Props) {
  const canvasRef = useRef<HTMLCanvasElement|null>(null);
  const drawing = useRef(false);
  const [empty, setEmpty] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#000';
  }, []);

  const pos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as any).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as any).clientY;
    return { x: clientX - rect.left, y: clientY - rect.top };
  };

  const start = (e: any) => { drawing.current = true; setEmpty(false); };
  const move = (e: any) => {
    if (!drawing.current) return;
    e.preventDefault();
    const { x, y } = pos(e);
    const ctx = canvasRef.current!.getContext('2d')!;
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
    if (onChange) onChange(canvasRef.current!.toDataURL('image/png'));
  };
  const end = () => {
    drawing.current = false;
    const ctx = canvasRef.current!.getContext('2d')!;
    ctx.beginPath();
    if (onChange) onChange(canvasRef.current!.toDataURL('image/png'));
  };

  const clear = () => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    setEmpty(true);
    if (onChange) onChange('');
  };

  return (
    <div className="space-y-2">
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className="border rounded shadow-sm touch-none"
        onMouseDown={start}
        onMouseMove={move}
        onMouseUp={end}
        onMouseLeave={end}
        onTouchStart={start}
        onTouchMove={move}
        onTouchEnd={end}
      />
      <div className="text-sm flex gap-2">
        <button type="button" onClick={clear} className="px-3 py-1 border rounded">Limpiar</button>
        <span className="opacity-70">{empty ? 'Firme dentro del recuadro' : 'Firma capturada'}</span>
      </div>
    </div>
  );
}

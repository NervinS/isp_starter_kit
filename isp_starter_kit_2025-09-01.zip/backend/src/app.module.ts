import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { DbModule } from './modules/db/db.module';

import { HealthModule } from './modules/health/health.module';
import { UsuariosModule } from './modules/usuarios/usuarios.module';
import { VentasModule } from './modules/ventas/ventas.module';
import { OrdenesModule } from './modules/ordenes/ordenes.module';
import { SmartoltModule } from './modules/smartolt/smartolt.module';
import { PlanesModule } from './modules/planes/planes.module';
import { AuthModule } from './modules/auth/auth.module';
import { CatalogosModule } from './modules/catalogos/catalogos.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    DbModule,
    HealthModule,
    UsuariosModule,
    VentasModule,
    OrdenesModule,
    SmartoltModule,
    PlanesModule,
    AuthModule,
    CatalogosModule,
  ],
})
export class AppModule {}

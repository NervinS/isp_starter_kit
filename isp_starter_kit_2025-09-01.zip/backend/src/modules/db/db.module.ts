import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forRoot({
    type: 'postgres',
    url: process.env.POSTGRES_URL || 'postgres://ispuser:isppass@127.0.0.1:5432/ispdb',
    autoLoadEntities: true,
    synchronize: false
  })],
})
export class DbModule {}

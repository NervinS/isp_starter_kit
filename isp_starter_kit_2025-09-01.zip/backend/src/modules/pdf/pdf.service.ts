import { Injectable } from '@nestjs/common';
import PDFDocument = require('pdfkit');

type ReciboArgs = {
  ventaCodigo: string;
  cliente: string;
  documento: string;
  planNombre: string;
  incluyeTv: boolean;
  altaCosto: number;
  mensual: number;
  mensualTv: number;
  fecha: Date;
};

type ContratoArgs = {
  ventaCodigo: string;
  cliente: string;
  documento: string;
  planNombre: string;
  incluyeTv: boolean;
  mensualTotal: number;
  fecha: Date;
  /** Firma del cliente; PNG o JPG. Si no viene, se deja la línea vacía. */
  firmaPng?: Buffer | null;
};

function peso(n: number) {
  try {
    return n.toLocaleString('es-CO');
  } catch {
    return new Intl.NumberFormat('es-CO').format(n);
  }
}

function fechaLarga(d: Date) {
  try {
    return d.toLocaleString('es-CO');
  } catch {
    return new Intl.DateTimeFormat('es-CO', {
      dateStyle: 'full',
      timeStyle: 'short',
    }).format(d);
  }
}

@Injectable()
export class PdfService {
  // -------------------------------
  // RECIBO
  // -------------------------------
  async reciboVenta(a: ReciboArgs): Promise<Buffer> {
    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));

    // Encabezado
    doc
      .fontSize(18)
      .text('RECIBO DE PAGO', { align: 'center' })
      .moveDown(0.5);
    doc
      .fontSize(10)
      .text(`Venta: ${a.ventaCodigo}`, { align: 'center' })
      .text(`Fecha: ${fechaLarga(a.fecha)}`, { align: 'center' })
      .moveDown(1.5);

    // Cliente
    doc.fontSize(12).text(`Cliente: ${a.cliente}`);
    doc.text(`Documento: ${a.documento}`).moveDown(0.7);

    // Plan
    doc.text(`Plan: ${a.planNombre}`);
    doc.text(`Incluye TV: ${a.incluyeTv ? 'Sí' : 'No'}`).moveDown(0.7);

    // Desglose
    doc
      .fontSize(12)
      .text(`Cargo de instalación (hoy): $${peso(a.altaCosto)}`);
    doc.text(`Mensual Internet: $${peso(a.mensual)}`);
    doc.text(`Mensual TV: $${peso(a.mensualTv)}`);

    // Footer
    const bottom = doc.page.height - doc.page.margins.bottom;
    doc
      .fontSize(9)
      .text('Gracias por su pago.', 40, bottom - 20, { align: 'center', width: doc.page.width - 80 });

    doc.end();
    await new Promise((r) => doc.on('end', r));
    return Buffer.concat(chunks);
  }

  // -------------------------------
  // CONTRATO (con firma)
  // -------------------------------
  async contrato(a: ContratoArgs): Promise<Buffer> {
    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(c));

    // Encabezado
    doc
      .fontSize(18)
      .text('CONTRATO DE SERVICIOS', { align: 'center' })
      .moveDown(0.5);
    doc
      .fontSize(10)
      .text(`Venta: ${a.ventaCodigo}`, { align: 'center' })
      .text(`Fecha de firma: ${fechaLarga(a.fecha)}`, { align: 'center' })
      .moveDown(1.5);

    // Partes
    doc
      .fontSize(12)
      .text(`Cliente: ${a.cliente}`)
      .text(`Documento: ${a.documento}`)
      .text(`Plan: ${a.planNombre} ${a.incluyeTv ? '(con TV)' : ''}`)
      .text(`Mensualidad Total: $${peso(a.mensualTotal)}`)
      .moveDown(1);

    // Texto del contrato (resumen)
    const clausulas =
      'Las partes acuerdan las condiciones de prestación del servicio, ' +
      'incluyendo instalación, pagos mensuales, soporte técnico y políticas de uso. ' +
      'El cliente declara haber leído y aceptado los términos.';
    doc.fontSize(11).text(clausulas, { align: 'justify' }).moveDown(2);

    // Área de firma
    const yFirmaLinea = 700;
    doc
      .moveTo(60, yFirmaLinea)
      .lineTo(340, yFirmaLinea)
      .stroke();
    doc.fontSize(10).text('Firma del cliente', 60, yFirmaLinea + 5);

    // Estampar firma (si viene)
    if (a.firmaPng && a.firmaPng.length > 10) {
      try {
        // Ajuste para que quepa sobre la línea
        doc.image(a.firmaPng, 60, yFirmaLinea - 80, { width: 260 });
      } catch {
        // Si no es válida, ignoramos sin romper el PDF
      }
    }

    // Footer
    const bottom = doc.page.height - doc.page.margins.bottom;
    doc
      .fontSize(9)
      .text('Este documento fue generado electrónicamente.', 40, bottom - 20, {
        align: 'center',
        width: doc.page.width - 80,
      });

    doc.end();
    await new Promise((r) => doc.on('end', r));
    return Buffer.concat(chunks);
  }
}

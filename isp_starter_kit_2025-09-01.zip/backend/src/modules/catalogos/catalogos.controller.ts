import { Controller, Get, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';

@Controller('catalogos')
export class CatalogosController {
  constructor(@InjectDataSource() private readonly ds: DataSource) {}

  // GET /v1/catalogos/municipios
  @Get('municipios')
  async municipios() {
    try {
      const rows = await this.ds.query<
        { codigo: string; nombre: string }[]
      >(
        `SELECT codigo, nombre
           FROM municipios
          WHERE activo = true
          ORDER BY nombre ASC`
      );
      return rows;
    } catch (e: any) {
      return { ok: false, err: e?.message || String(e) };
    }
  }

  // GET /v1/catalogos/vias
  @Get('vias')
  async vias() {
    try {
      const rows = await this.ds.query<
        { codigo: string; nombre: string }[]
      >(
        `SELECT codigo, nombre
           FROM vias
          WHERE activo = true
          ORDER BY nombre ASC`
      );
      return rows;
    } catch (e: any) {
      return { ok: false, err: e?.message || String(e) };
    }
  }

  // GET /v1/catalogos/sectores?municipio=BARRANQUILLA&zona=BARRIO
  @Get('sectores')
  async sectores(
    @Query('municipio') municipio?: string,
    @Query('zona') zona?: string,
  ) {
    try {
      if (!municipio || !zona) return [];
      const rows = await this.ds.query<{ nombre: string }[]>(
        `SELECT nombre
           FROM sectores
          WHERE municipio_codigo = $1
            AND zona = $2
            AND activo = true
          ORDER BY nombre ASC`,
        [municipio, zona],
      );
      return rows.map(r => r.nombre);
    } catch (e: any) {
      return { ok: false, err: e?.message || String(e) };
    }
  }
}

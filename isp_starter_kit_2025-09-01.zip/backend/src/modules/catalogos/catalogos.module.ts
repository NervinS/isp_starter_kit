import { Module } from '@nestjs/common';
import { CatalogosController } from './catalogos.controller';

// OJO: No importamos TypeOrmModule.forFeature(...) aquí para evitar ciclos.
// Usamos DataSource directo en el controller.

@Module({
  controllers: [CatalogosController],
})
export class CatalogosModule {}

import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'vias' })
export class Via {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ unique: true }) codigo: string;  // CALLE, AVENIDA...
  @Column() nombre: string;                  // texto a mostrar
  @Column({ default: true }) activo: boolean;
}

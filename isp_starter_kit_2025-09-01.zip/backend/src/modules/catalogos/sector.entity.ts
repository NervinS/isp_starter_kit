import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'sectores' })
export class Sector {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() municipio_codigo: string;   // FK a municipios.codigo
  @Column() zona: 'BARRIO' | 'CONJUNTO' | 'COMUNA';
  @Column() nombre: string;
  @Column({ default: true }) activo: boolean;
}

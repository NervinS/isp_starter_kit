// src/app.module.ts
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

// Si ya tienes un módulo que configura TypeORM, mantenlo:
import { DbModule } from './modules/db/db.module';

// Módulos de tu app
import { HealthModule } from './modules/health/health.module';
import { UsuariosModule } from './modules/usuarios/usuarios.module';
import { VentasModule } from './modules/ventas/ventas.module';
import { OrdenesModule } from './modules/ordenes/ordenes.module';
import { SmartoltModule } from './modules/smartolt/smartolt.module';
import { PlanesModule } from './modules/planes/planes.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    DbModule,           // <- tu módulo de DB (deja este si ya lo usabas)
    HealthModule,
    UsuariosModule,
    VentasModule,
    OrdenesModule,
    SmartoltModule,
    PlanesModule,       // <- importante: registrar planes
  ],
})
export class AppModule {}

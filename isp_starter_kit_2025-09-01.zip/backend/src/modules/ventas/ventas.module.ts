import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { VentasController } from './ventas.controller';
import { Venta } from './ventas.entity';
import { Usuario } from '../usuarios/usuario.entity';
import { Orden } from '../ordenes/orden.entity';
import { Plan } from '../planes/plan.entity';

// Proveedores que usa VentasController
import { MinioService } from '../storage/minio.service';
import { PdfService } from '../pdf/pdf.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Venta, Usuario, Orden, Plan]),
  ],
  controllers: [VentasController],
  providers: [MinioService, PdfService],
})
export class VentasModule {}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrdenesController } from './ordenes.controller';
import { Orden } from './orden.entity';
import { Evidencia } from './evidencia.entity';
import { MinioService } from '../storage/minio.service';
import { Usuario } from '../usuarios/usuario.entity';
import { SmartoltModule } from '../smartolt/smartolt.module';

@Module({
  imports: [TypeOrmModule.forFeature([Orden, Evidencia, Usuario]), SmartoltModule],
  controllers: [OrdenesController],
  providers: [MinioService],
})
export class OrdenesModule {}

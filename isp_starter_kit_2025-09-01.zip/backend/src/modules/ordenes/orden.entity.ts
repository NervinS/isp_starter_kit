import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'ordenes' })
export class Orden {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Column({ length: 20, unique: true }) codigo: string;
  @Column({ type: 'uuid' }) venta_id: string;
  @Column({ type: 'uuid' }) usuario_id: string;

  @Column({ length: 30, default: 'instalacion' }) tipo: string;
  @Column({ length: 20, default: 'pendiente' }) estado: string;

  // técnicos
  @Column({ type: 'double precision', nullable: true }) lat?: number;
  @Column({ type: 'double precision', nullable: true }) lng?: number;
  @Column({ length: 40, nullable: true }) onu_serial?: string;
  @Column({ length: 20, nullable: true }) vlan?: string;
  @Column({ length: 40, nullable: true }) precinto?: string;
  @Column({ length: 80, nullable: true }) cerrada_por?: string;
  @Column({ type: 'timestamptz', nullable: true }) cerrada_at?: Date;

  @Column({ type: 'timestamptz', default: () => 'now()' }) created_at: Date;
}

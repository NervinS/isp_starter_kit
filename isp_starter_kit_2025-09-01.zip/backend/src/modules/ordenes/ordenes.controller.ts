import {
  BadRequestException,
  Controller,
  Get,
  NotFoundException,
  Param,
  Post,
  Query,
  Body,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entidades
import { Orden } from './orden.entity';
import { Evidencia } from './evidencia.entity';
import { Usuario } from '../usuarios/usuario.entity';

// Servicios auxiliares
import { MinioService } from '../storage/minio.service';
import { SmartoltQueue } from '../smartolt/smartolt.queue';
import { Roles } from '../../common/decorators/roles.decorator';

type CerrarDto = {
  lat?: number | null;
  lng?: number | null;
  onu_serial?: string | null;
  vlan?: string | null;
  precinto?: string | null;
  tecnico?: string | null;
  fotos?: string[];  // dataURL u object_key
  firma?: string;    // dataURL u object_key
};

const DATA_URL_RE = /^data:[a-z0-9.+-\/]+;base64,[A-Za-z0-9+/=]+$/i;

@Controller('ordenes')
export class OrdenesController {
  constructor(
    @InjectRepository(Orden)     private readonly ordenesRepo: Repository<Orden>,
    @InjectRepository(Evidencia) private readonly evidRepo: Repository<Evidencia>,
    @InjectRepository(Usuario)   private readonly usuariosRepo: Repository<Usuario>,
    private readonly minio: MinioService,
    private readonly smartQueue: SmartoltQueue,
  ) {}

  /** GET /v1/ordenes?estado=pendiente */
  @Roles('tecnico','admin')
  @Get()
  async listar(@Query('estado') estado?: string) {
    const qb = this.ordenesRepo
      .createQueryBuilder('o')
      .select([
        'o.codigo AS o_codigo',
        'o.estado AS o_estado',
        'o.tipo   AS o_tipo',
        'o.created_at AS o_created_at',
        'v.codigo AS v_codigo',
        'v.total  AS v_total',
        'u.codigo AS u_codigo',
        "concat(coalesce(u.nombre,''),' ',coalesce(u.apellido,'')) AS u_nombre",
      ])
      .leftJoin('ventas',   'v', 'v.id = o.venta_id')
      .leftJoin('usuarios', 'u', 'u.id = o.usuario_id');

    if (estado) qb.where('o.estado = :estado', { estado });
    qb.orderBy('o.created_at', 'DESC');

    const rows = await qb.getRawMany();
    return rows.map((r) => ([
      r.o_codigo,
      r.o_estado,
      r.o_tipo,
      r.o_created_at,
      r.v_codigo,
      r.v_total,
      (r.u_nombre || '').trim(),
      r.u_codigo,
    ])).map(([o_codigo,o_estado,o_tipo,o_created_at,v_codigo,v_total,u_nombre,u_codigo]) => ({
      codigo: o_codigo as string,
      estado: o_estado as string,
      tipo:   o_tipo as string,
      created_at: o_created_at as Date,
      venta:   { codigo: v_codigo as string, total: v_total as string },
      usuario: { codigo: u_codigo as string, nombre: u_nombre as string },
    }));
  }

  /** POST /v1/ordenes/:codigo/cerrar */
  @Roles('tecnico','admin')
  @Post(':codigo/cerrar')
  async cerrar(@Param('codigo') codigo: string, @Body() body: CerrarDto = {}) {
    const orden = await this.ordenesRepo.findOne({ where: { codigo } });
    if (!orden) throw new NotFoundException('Orden no existe');

    orden.lat         = (body.lat ?? orden.lat) ?? null;
    orden.lng         = (body.lng ?? orden.lng) ?? null;
    orden.onu_serial  = (body.onu_serial ?? orden.onu_serial) ?? null;
    orden.vlan        = (body.vlan ?? orden.vlan) ?? null;
    orden.precinto    = (body.precinto ?? orden.precinto) ?? null;
    orden.cerrada_por = body.tecnico || 'tecnico-demo';
    orden.cerrada_at  = new Date();
    orden.estado      = 'cerrada';
    await this.ordenesRepo.save(orden);

    // Activa en OLT si corresponde
    if (orden.onu_serial && orden.vlan) {
      this.smartQueue.enqueueActivacion({
        ordenCodigo: orden.codigo,
        serial: orden.onu_serial,
        vlan: orden.vlan,
      });
    }

    // ✅ Actualiza estado del usuario si la orden es de instalación
    if (orden.tipo === 'instalacion' && orden.usuario_id) {
      try {
        await this.usuariosRepo.update({ id: orden.usuario_id }, { estado: 'instalado' });
      } catch (e) {
        // no rompas la respuesta principal
        console.warn(`[ordenes/cerrar] No se pudo poner usuario instalado para ${codigo}:`, e);
      }
    }

    return {
      ok: true,
      orden: {
        codigo: orden.codigo,
        estado: orden.estado,
        lat: orden.lat,
        lng: orden.lng,
        onu_serial: orden.onu_serial,
        vlan: orden.vlan,
        precinto: orden.precinto,
      },
      evidencias: [],
    };
  }

  /** POST /v1/ordenes/:codigo/cerrar-completo */
  @Roles('tecnico','admin')
  @Post(':codigo/cerrar-completo')
  async cerrarCompleto(@Param('codigo') codigo: string, @Body() body: CerrarDto) {
    if (!body || typeof body !== 'object') {
      throw new BadRequestException('Body requerido');
    }
    if (!Array.isArray(body.fotos) || body.fotos.length === 0) {
      throw new BadRequestException('Al menos 1 foto requerida');
    }
    if (!body.firma) {
      throw new BadRequestException('Firma requerida');
    }

    const orden = await this.ordenesRepo.findOne({ where: { codigo } });
    if (!orden) throw new NotFoundException('Orden no existe');

    orden.lat         = (body.lat ?? orden.lat) ?? null;
    orden.lng         = (body.lng ?? orden.lng) ?? null;
    orden.onu_serial  = (body.onu_serial ?? orden.onu_serial) ?? null;
    orden.vlan        = (body.vlan ?? orden.vlan) ?? null;
    orden.precinto    = (body.precinto ?? orden.precinto) ?? null;
    orden.cerrada_por = body.tecnico || 'tecnico-demo';
    orden.cerrada_at  = new Date();
    orden.estado      = 'cerrada';
    await this.ordenesRepo.save(orden);

    const saved: Array<{ tipo: 'foto' | 'firma'; object_key: string }> = [];
    const prefix = `ordenes/${orden.codigo}`;

    // Fotos (máx 5)
    const pics = body.fotos.slice(0, 5);
    for (const foto of pics) {
      let objectKey: string | undefined;
      let mime: string | undefined;
      let size: number | undefined;

      if (typeof foto === 'string' && foto.startsWith('data:')) {
        const up = await this.minio.saveBase64(foto, prefix);
        objectKey = up.objectKey;
        mime = up.mime;
        size = up.size;
      } else if (typeof foto === 'string' && foto.startsWith(prefix)) {
        objectKey = foto;
        mime = this.mimeFromObjectKey(objectKey);
      } else {
        throw new BadRequestException('Formato de foto inválido (esperado data:... o object_key)');
      }

      const ev = this.evidRepo.create({
        orden_id: orden.id,
        tipo: 'foto',
        object_key: objectKey,
        mime,
        size,
      });
      await this.evidRepo.save(ev);
      saved.push({ tipo: 'foto', object_key: objectKey });
    }

    // Firma
    {
      const firma = body.firma;
      let objectKey: string | undefined;
      let mime: string | undefined;
      let size: number | undefined;

      if (typeof firma === 'string' && firma.startsWith('data:')) {
        const up = await this.minio.saveBase64(firma, prefix);
        objectKey = up.objectKey;
        mime = up.mime;
        size = up.size;
      } else if (typeof firma === 'string' && firma.startsWith(prefix)) {
        objectKey = firma;
        mime = this.mimeFromObjectKey(objectKey) || 'image/png';
      } else {
        throw new BadRequestException('Formato de firma inválido (esperado data:... o object_key)');
      }

      const evFirma = this.evidRepo.create({
        orden_id: orden.id,
        tipo: 'firma',
        object_key: objectKey,
        mime,
        size,
      });
      await this.evidRepo.save(evFirma);
      saved.push({ tipo: 'firma', object_key: objectKey });
    }

    // Activación en OLT si aplica
    if (orden.onu_serial && orden.vlan) {
      this.smartQueue.enqueueActivacion({
        ordenCodigo: orden.codigo,
        serial: orden.onu_serial,
        vlan: orden.vlan,
      });
    }

    // ✅ Actualiza estado del usuario si la orden es de instalación
    if (orden.tipo === 'instalacion' && orden.usuario_id) {
      try {
        await this.usuariosRepo.update({ id: orden.usuario_id }, { estado: 'instalado' });
      } catch (e) {
        console.warn(`[ordenes/cerrar-completo] No se pudo poner usuario instalado para ${codigo}:`, e);
      }
    }

    return {
      ok: true,
      orden: {
        codigo: orden.codigo,
        estado: orden.estado,
        lat: orden.lat,
        lng: orden.lng,
        onu_serial: orden.onu_serial,
        vlan: orden.vlan,
        precinto: orden.precinto,
      },
      evidencias: saved,
    };
  }

  // Helper
  private mimeFromObjectKey(key: string): string | undefined {
    const k = key.toLowerCase();
    if (k.endsWith('.jpg') || k.endsWith('.jpeg')) return 'image/jpeg';
    if (k.endsWith('.png')) return 'image/png';
    if (k.endsWith('.webp')) return 'image/webp';
    return undefined;
  }
}

import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private jwt: JwtService, private reflector: Reflector) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    // 1) Endpoints públicos
    const isPublic =
      this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
        ctx.getHandler(),
        ctx.getClass(),
      ]) ?? false;
    if (isPublic) return true;

    // 2) Leer Authorization de forma segura
    const req = ctx.switchToHttp().getRequest<{ headers?: any; user?: any }>();
    const authHeader =
      typeof req?.headers?.authorization === 'string'
        ? req.headers.authorization
        : '';
    if (!authHeader.startsWith('Bearer '))
      throw new UnauthorizedException('Falta Bearer token');

    // 3) Verificar token
    try {
      const token = authHeader.slice(7);
      const payload = await this.jwt.verifyAsync(token); // { sub, username, roles }
      req.user = payload;
      return true;
    } catch {
      throw new UnauthorizedException('JWT inválido o expirado');
    }
  }
}

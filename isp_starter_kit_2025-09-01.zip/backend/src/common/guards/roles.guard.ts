import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY, AppRole } from '../decorators/roles.decorator';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    // 1) Público => no exige roles
    const isPublic =
      this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
        ctx.getHandler(),
        ctx.getClass(),
      ]) ?? false;
    if (isPublic) return true;

    // 2) Roles requeridos en handler/clase
    const required =
      this.reflector.getAllAndOverride<AppRole[]>(ROLES_KEY, [
        ctx.getHandler(),
        ctx.getClass(),
      ]) || [];

    if (!required.length) return true; // si no hay @Roles, no restringe

    // 3) Roles del usuario (defensivo)
    const req = ctx.switchToHttp().getRequest<{ user?: any }>();
    const roles: string[] = Array.isArray(req?.user?.roles)
      ? req.user.roles.map((r: any) => String(r).toLowerCase())
      : [];

    const ok = required.some((r) => roles.includes(String(r).toLowerCase()));
    if (!ok) throw new ForbiddenException('No tienes permiso');
    return true;
  }
}

/**
 * Habilita metadatos de reflexión usados por Nest y decorators (p.ej. @Injectable).
 */
import 'reflect-metadata';

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

import * as bodyParser from 'body-parser';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });

  // Body limits (permite fotos/firma en base64)
  app.use(bodyParser.json({ limit: '30mb' }));
  app.use(bodyParser.urlencoded({ extended: true, limit: '30mb' }));

  // Prefijo global
  app.setGlobalPrefix('v1');

  // CORS
  const isDev = process.env.NODE_ENV !== 'production';
  const allowlist = new Set<string>([
    'http://localhost:3001',
    'http://127.0.0.1:3001',
    'http://192.168.1.140:3001',
    'http://38.188.225.6:3001',
    'http://38.188.225.6:3002',
    'http://192.168.1.140:3002',
  ]);

  app.enableCors({
    origin: (origin, cb) => {
      if (isDev || !origin) return cb(null, true);
      return cb(null, allowlist.has(origin));
    },
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  });

  // Swagger
  const swaggerConfig = new DocumentBuilder()
    .setTitle('ISP FTTH API')
    .setDescription('Documentación de endpoints del backend')
    .setVersion('1.0.0')
    .build();
  const swaggerDoc = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('v1/docs', app, swaggerDoc);

  const port = Number(process.env.PORT) || 3000;
  const host = process.env.HOST || '0.0.0.0';
  await app.listen(port, host);
  console.log(`API running on http://${host}:${port}/v1/health`);
}

bootstrap();
